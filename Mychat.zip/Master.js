$.getScript("https://shamre.000webhostapp.com/Omar.js");

$(`<div class="rainbow"><div class="rainbow"><img src="https://shamre.000webhostapp.com/Nsh.jpg" class="fl" style="width:100%;margin-top: 1px;background-color: white;">
<a href="/contact" target="_blank" style="background-color: white;padding: 0;height: 23px;width: 20%;font-size: 100%!important;border-radius: 0 15px;margin-left: 2px;color: #0899B8;background-image: none;border-color: #0899B8 #066276 #09a7c9 #086579" type="a" class="btn btn-defaultf">اتصل بنا<i style="margin-left: 2px;" class="fa fa-star-o"></i></a>
<a href="/agents" target="_blank" type="a" style="background-image: none;padding: 0;height: 23px;width: 19%;font-size: 100%!important;color: #09a7c9;border-color: #0899B8 #066276 #09a7c9 #086579" class="btn btn-default ">وكلائنا<i style="margin-left: 2px;" class="fa fa-heart-o"></i></a>
<a href="/offers" target="_blank" type="a" style="background-image: none;padding: 0;height: 23px;width: 19%;font-size: 100%!important;color: #09a7c9;border-color: #0899B8 #066276 #09a7c9 #086579;" class="btn btn-default">عروضنا<i style="margin-left: 2px;" class="fa fa-eye"></i></a>
<a href="/services" target="_blank" style="background-image: none;padding: 0;height: 23px;width: 20%;font-size: 100%!important;margin-right: -5px;border-radius: 15px 0;border-color: #0899B8 #066276 #09a7c9 #086579;color: #09a7c9;" type="a" class="btn btn-default">خدماتنا<i style="margin-left: 2px;" class="fa fa-comments-o"></i></a>
    </div> 
 `).insertBefore('.nav-tabs');
 
$(`<link rel="stylesheet" type="text/css" href="//www.fontstatic.com/f=jazeera-light,jazeera">
<link rel="stylesheet" type="text/css" href="https://shamre.000webhostapp.com/Master.css">
</style>`).insertBefore('body');

$('.loginstat').removeClass('fl').addClass('fr').css({"margin-right":"2px","margin-left":"-12px"}).appendTo('a.label.label-primary.fl')
$('.badgex').insertBefore('.nav-tabs').css({"position": "absolute","margin": "auto auto","right": "0","left": "3px","display": "block","float": "right","width": "40px","top": "69px"})

$('div#tlogins div#l1 input,div#tlogins div#l2 input,div#tlogins div#l3 input').addClass('form-control primaryborder').css({'text-align':'center','max-width':'40%','float': 'right'})
$('div#l1 br,div#l2 br,div#l3 br').remove()
$('input#stealth').css('max-width','15px').removeClass('form-control')
$('#l2 .checkbox label').html($('#l2 .checkbox label input')[0].outerHTML)
$('#l2 .checkbox').css({"margin":"7px -5px 0 0","float":"right"})
$('ul.nav.nav-tabs,.nav-tabs>li>a').addClass('label-primary').css({"color":"white","padding":"4px 0px"})
$('ul.nav.nav-tabs').css({"padding":"0px"})
$('input#u1').css({"max-width":"80%"})
$(`<center><div><div width="75.5%" style="background-color: #b7c3c5; color: #BF4A47;border-radius: 5px 5px 5px5px;border-bottom: 2px solid #ffffff;border-top: 2px solid#ffffff;padding-bottom: 2px!important;"><font style="background-color: #fff;border-radius: 0px 25px 0px 25px;font-family: 'Cairo', sans-serif, FontAwesome;padding: 2px 10px 2px 10px; margin:0px 25px 0px 25px;" > شات نجمة للجوال </font></div></div><center>`).insertBefore('#d2');
